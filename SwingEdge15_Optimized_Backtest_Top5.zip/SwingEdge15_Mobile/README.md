# SwingEdge 15 Mobile (PWA)

A mobile-first, installable Progressive Web App for screening Nifty 500 stocks for swing-trade setups targeting 10% within up to 15 trading days.

## Important data limitation
This starter app uses Yahoo Finance via `yfinance`, a free community data source. It is **not** a guaranteed real-time or millisecond market-data feed. The UI refresh interval is configurable, but refreshes only request whatever freshness the upstream provider supports. The default is 60 seconds. Millisecond polling would overload the provider and still would not create millisecond-fresh data.

## Architecture
- `frontend/`: installable PWA (React + Vite), designed for phone screens.
- `backend/`: FastAPI service using `yfinance` and pandas to compute technical signals.
- Nifty 500 universe is fetched from the public Nifty Indices constituents CSV when available; a manual symbol search is also supported.

## Run locally
Requirements: Node.js 20+, Python 3.10+.

### 1. Start backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 2. Start frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```
Open the URL printed by Vite. On a phone on the same Wi-Fi, use your computer's local IP address and port 5173.

For local development, the frontend defaults to `http://localhost:8000`. For deployment, set `VITE_API_BASE_URL` to your deployed backend URL.

## Install on a phone
Deploy the frontend to a static host (for example Vercel) and the backend to a Python host that supports FastAPI. Open the deployed frontend in Chrome/Android or Safari/iOS and choose **Add to Home Screen** / **Install App**. HTTPS is required for PWA installation and notifications.

## Included
- Mobile dashboard with search and Nifty 500 symbol lookup
- Technical indicators: RSI, MACD, SMA20/50/200, ADX, ATR, relative volume, recent highs, 5/20-day returns
- Indicative 10% target and ATR-based stop level
- Score / watch signal (not a promise of return)
- Refresh interval control and manual refresh
- Watchlist saved in browser local storage
- CSV export of analyzed symbols
- PWA manifest and service worker

## Not included yet
- Broker login/order execution
- Guaranteed live exchange feed
- Server-side scheduled scans or push alerts while the app is closed
- Backtested/validated predictive probabilities

## Risk warning
A 10% move within 15 days cannot be guaranteed. Signals are rule-based research aids, not personalized investment advice. Free data can be delayed, incomplete, rate-limited, or unavailable. Verify prices and corporate actions with your broker/exchange before trading.

## Backtesting engine and Top 5 (research baseline)
- **Top 5** tab calls `GET /top5`, ranks current technical candidates from a batch of up to 50 symbols, and shows historical hit rate only when an explicit backtest has produced at least 30 out-of-sample trades for that symbol.
- The default batch rotates through the current constituents list by day. It is **not** a simultaneous ranking of all 500 stocks. Pass `?symbols=RELIANCE,INFY,BEL` to scan a specified list.
- **Backtest** tab calls `POST /backtest` for up to 30 symbols, defaulting to five years of daily history, a 10% target, 15-session horizon, score threshold 68, ATR-based 2× stop, and a 30 bps round-trip cost assumption.
- Signals are calculated after the signal day's close and entries are simulated at the next session's open. The final 30% of the time series is out-of-sample. If target and stop are both touched within one daily candle, the simulation conservatively assumes the stop occurred first.
- Backtest output includes development and out-of-sample metrics, target-hit rate, average net return, profit factor, drawdown and a rough binomial confidence interval for the pooled OOS target-hit rate.
- The app stores the most recent per-symbol backtest profiles in backend memory only. Restarting the backend clears them. This release does not persist validation artifacts, execute trades, or establish that the strategy is profitable.

### Important validation caveats
This is a baseline simulation, not a certified strategy validation. Yahoo Finance history availability and current constituent lists can create survivorship bias; historical index membership is not reconstructed. Signals can overlap, the pooled confidence interval assumes independence that may not hold, corporate-action adjustment and daily-bar stop/target ambiguity can affect results, and a 30-trade threshold is only a minimum display gate—not proof of statistical reliability. Do not trade on the displayed metrics without independent review and paper-trading.
